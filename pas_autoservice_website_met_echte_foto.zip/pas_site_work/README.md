# P.A.S. Autoservice website

Static website gebaseerd op het aangeleverde ontwerp. De adminpagina en boekingsfunctionaliteit zijn verwijderd.

Open `public/index.html` in een browser of host de map `public` als statische website.
